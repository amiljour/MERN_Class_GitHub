
function App() {

  const x = 3;
  const message = "hello";

  console.log("hello");

  return (
    <>
      <h1 className='red'>{message}</h1>
      <p>this is cool {x}</p>
    </ >
  );
}

export default App;
